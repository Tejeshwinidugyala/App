import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-groups',
  templateUrl: './add-groups.component.html',
  styleUrls: ['./add-groups.component.less']
})
export class AddGroupsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
