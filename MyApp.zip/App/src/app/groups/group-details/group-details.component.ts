import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-details',
  templateUrl: './group-details.component.html',
  styleUrls: ['./group-details.component.less'],
})
export class GroupDetailsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {
    console.log('group details');
  }
}
