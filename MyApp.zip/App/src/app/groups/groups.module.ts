import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from './../shared/shared.module';
import { AddGroupsComponent } from './add-groups/add-groups.component';
import { GroupListComponent } from './group-list/group-list.component';
import { GroupsRoutingModule } from './groups-routing.module';
import { LayoutComponent } from './layout/layout.component';
import { GroupDetailsComponent } from './group-details/group-details.component';

@NgModule({
  declarations: [LayoutComponent, AddGroupsComponent, GroupListComponent, GroupDetailsComponent],
  imports: [CommonModule, GroupsRoutingModule, SharedModule],
})
export class GroupsModule {}
