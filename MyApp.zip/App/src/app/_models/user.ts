﻿export class User {
  id: string;
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  token: string;
}

export class Group {
  id: string;
  name: string;
  location: string;
}

export class Contact {
  id: string;
  name: string;
  phoneNumber: string;
  designation: string;
  specialization: string;
}
