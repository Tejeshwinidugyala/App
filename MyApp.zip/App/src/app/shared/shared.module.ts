import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AddEditComponent } from './add-edit.component';
import { ListComponent } from './list.component';

@NgModule({
  declarations: [AddEditComponent, ListComponent],
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  exports: [AddEditComponent, ListComponent],
})
export class SharedModule {}
