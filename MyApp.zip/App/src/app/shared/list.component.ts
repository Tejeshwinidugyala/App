﻿import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService, AlertService } from '@app/_services';
import { Subject } from 'rxjs';
import { first, takeUntil } from 'rxjs/operators';

export enum UserType {
  group = 'group',
  contact = 'contact',
}

@Component({ selector: 'app-record-list', templateUrl: 'list.component.html' })
export class ListComponent implements OnInit, OnDestroy {
  @Input() type: string;
  userData = null;
  hasData = false;
  private destroyed$: Subject<boolean> = new Subject<boolean>();
  constructor(
    private accountService: AccountService,
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService
  ) {}

  ngOnInit() {
    this.accountService
      .getUserGroup()
      .pipe(first())
      .subscribe((groups) => {
        if (!!groups) {
          this.userData = groups;
          this.hasData = groups.length > 0 ? true : false;
        } else {
          this.hasData = false;
        }
      });
  }

  deleteUser(id: string) {
    const user = this.userData.find((x) => x.id === id);
    user.isDeleting = true;
    this.accountService
      .delete(id)
      .pipe(takeUntil(this.destroyed$))
      .subscribe(
        () => (this.userData = this.userData.filter((x) => x.id !== id))
      );
  }

  deleteData(id: string) {
    const user = this.userData.find((x) => x.id === id);
    user.isDeleting = true;
    this.accountService
      .deleteUserGroup(id)
      .pipe(takeUntil(this.destroyed$))
      .subscribe(
        (isDeleted) => {
          if (isDeleted) {
            this.userData = this.userData.filter((x) => x.id !== id);
          }
        },
        (error) => {
          this.alertService.error(error);
        }
      );
  }

  add() {
    if (this.type === UserType.group) {
      this.router.navigate(['add'], { relativeTo: this.route });
    } else {
      //  this.router.navigate(['add'], { relativeTo: this.route });
    }
  }
  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
}
